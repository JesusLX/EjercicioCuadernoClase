<?php
// Routes
/*
$app->get('/[{name}]', function ($request, $response, $args) {
    // Sample log message
    $this->logger->info("Slim-Skeleton '/' route");

    // Render index view
    return $this->renderer->render($response, 'index.phtml', $args);
});
*/

$app->get("/", function ($request, $response) {
  return $this->response->write(
      "<h1>RESTful API Slim</h1>
        <a href ='doc/index.html'>API Documentation</a>");
});

// get all studens
$app->get('/student', function ($request, $response) {
  $key = $request->getHeader('apikey');
    if ($key[0] != "noselodigasanadie"){
      $result->setCode(FALSE);
      $result->setStatus(403);
      $result->setMessage("Error: "."Forbidden access");
    }else{
      
  $result = new Result();
  try {
    $dbquery = $this->db->prepare("SELECT * FROM " . TABLE . " ORDER BY surname");
    $dbquery->execute();
    $studens = $dbquery->fetchAll();
    $result->setCode(TRUE);
    $result->setStatus(OK);
    $result->setStudents($studens);
  } catch (PDOException $e) {
    $result->setCode(FALSE);
    $result->setStatus(CONFLICT);
    $result->setMessage("Error: " . $e->getMessage());
  }
  return $this->response->withJson($result);
  }
});

// get all incidences
$app->get('/incidence', function ($request, $response) {
  $key = $request->getHeader('apikey');
    if ($key[0] != "noselodigasanadie"){
      $result->setCode(FALSE);
      $result->setStatus(403);
      $result->setMessage("Error: "."Forbidden access");
    }else{
      
  $result = new Result();
  try {
    $dbquery = $this->db->prepare("SELECT i.id,i.id_student,i.faltas,i.trabajo,i.actitud,i.observaciones,i.date,s.name FROM " .
                                 TABLE_INCIDENCES." i INNER JOIN ".TABLE." s ON i.id_student = s.id  WHERE i.date = CURDATE()");
    $dbquery->execute();
    $studens = $dbquery->fetchAll();
    $result->setCode(TRUE);
    $result->setStatus(OK);
    $result->setIncidences($studens);
  } catch (PDOException $e) {
    $result->setCode(FALSE);
    $result->setStatus(CONFLICT);
    $result->setMessage("Error: " . $e->getMessage());
  }
  return $this->response->withJson($result);
}
});

// get one student
$app->get('/student/[{id}]', function ($request, $response, $args) {
  $result = new Result();
   $key = $request->getHeader('apikey');
    if ($key[0] != "noselodigasanadie"){
      $result->setCode(FALSE);
      $result->setStatus(403);
      $result->setMessage("Error: "."Forbidden access");
    }else{
      
  try {
    $dbquery = $this->db->prepare("SELECT * FROM " . TABLE." WHERE id = ?");
    $dbquery->bindParam(1, $args['id']);
    $dbquery->execute();
    $studen = $dbquery->fetchObject();
    if ($studen != null) {
      $result->setCode(TRUE);
      $result->setStatus(OK);
      $result->setStudents($studen);
    } else {
      $result->setCode(FALSE);
      $result->setStatus(NOT_COMPLETED);
      $result->setMessage("Does the student exist?");
    }
    } catch (PDOException $e) {
      $result->setCode(FALSE);
      $result->setStatus(CONFLICT);
      $result->setMessage("Error: " . $e->getMessage());
    }
  return $this->response->withJson($result);
    }
});

// get one incidence
$app->get('/incidence/[{id}]', function ($request, $response, $args) {
  $result = new Result();
   $key = $request->getHeader('apikey');
    if ($key[0] != "noselodigasanadie"){
      $result->setCode(FALSE);
      $result->setStatus(403);
      $result->setMessage("Error: "."Forbidden access");
    }else{
      
  try {
    $dbquery = $this->db->prepare("SELECT i.id,i.id_student,i.faltas,i.trabajo,i.actitud,i.observaciones,i.date,s.name FROM " . TABLE_INCIDENCES." i INNER JOIN ".TABLE." s ON i.id_student = s.id  WHERE i.date = CURDATE() AND i.id = ?");
    $dbquery->bindParam(1, $args['id']);
    $dbquery->execute();
    $incidence = $dbquery->fetchObject();
    if ($incidence != null) {
      $result->setCode(TRUE);
      $result->setStatus(OK);
      $result->setIncidences($incidence);
    } else {
      $result->setCode(FALSE);
      $result->setStatus(NOT_COMPLETED);
      $result->setMessage("Does the incidence exist?");
    }
    } catch (PDOException $e) {
      $result->setCode(FALSE);
      $result->setStatus(CONFLICT);
      $result->setMessage("Error: " . $e->getMessage());
    }
  return $this->response->withJson($result);
    }
});

//aniadir student
$app->post('/student', function ($request, $response) {
  $result = new Result();
  //lock the table
   $key = $request->getHeader('apikey');
    if ($key[0] != "noselodigasanadie"){
      $result->setCode(FALSE);
      $result->setStatus(403);
      $result->setMessage("Error: "."Forbidden access");
    }else{
      
  try {
    $input = $request->getParsedBody();
    $dbquery = $this->db->prepare("INSERT INTO " . TABLE . " (name, surname, address , city , postalCode , phone , email) VALUES (?, ?, ?,?, ?, ?, ?)");
    $dbquery->bindParam(1, $input['name']);
    $dbquery->bindParam(2, $input['surname']);
    $dbquery->bindParam(3, $input['address']);
    $dbquery->bindParam(4, $input['city']);
    $dbquery->bindParam(5, $input['postalCode']);
    $dbquery->bindParam(6, $input['phone']);
    $dbquery->bindParam(7, $input['email']);
    $dbquery->execute();
    $number = $dbquery->rowCount();
    $lastId = $this->db->lastInsertId();
    if ($number > 0) {
      $result->setCode(TRUE);
      $result->setStatus(OK);
      $result->setLast($lastId);
    }
    else {
      $result->setCode(FALSE);
      $result->setStatus(NOT_COMPLETED);
      $result->setMessage("NOT INSERTED");
    }
    } catch (PDOException $e) {
      $result->setCode(FALSE);
      $result->setStatus(CONFLICT);
      $result->setMessage("Errorito: " . $e->getMessage());
    }
  return $this->response->withJson($result);
    }
});

//aniadir incidence
$app->post('/incidence', function ($request, $response) {
  $result = new Result();
  //lock the table
   $key = $request->getHeader('apikey');
    if ($key[0] != "noselodigasanadie"){
      $result->setCode(FALSE);
      $result->setStatus(403);
      $result->setMessage("Error: "."Forbidden access");
    }else{
      
  try {
    $input = $request->getParsedBody();
    $dbquery = $this->db->prepare("INSERT INTO " . TABLE_INCIDENCES . " (id_student, faltas, trabajo , actitud , observaciones, date ) VALUES (?, ?, ?,?, ?, ?)");
    $dbquery->bindParam(1, $input['id_student']);
    $dbquery->bindParam(2, $input['faltas']);
    $dbquery->bindParam(3, $input['trabajo']);
    $dbquery->bindParam(4, $input['actitud']);
    $dbquery->bindParam(5, $input['observaciones']);
    $dbquery->bindParam(6, $input['date']);
    $dbquery->execute();
    $number = $dbquery->rowCount();
    $lastId = $this->db->lastInsertId();
    if ($number > 0) {
      $result->setCode(TRUE);
      $result->setStatus(OK);
      $result->setLast($lastId);
    }
    else {
      $result->setCode(FALSE);
      $result->setStatus(NOT_COMPLETED);
      $result->setMessage("NOT INSERTED");
    }
    } catch (PDOException $e) {
      $result->setCode(FALSE);
      $result->setStatus(CONFLICT);
      $result->setMessage("Error: " . $e->getMessage());
    }
  return $this->response->withJson($result);
    }
});


$app->put('/student/[{id}]', function ($request, $response, $args) {
  $result = new Result();
   $key = $request->getHeader('apikey');
    if ($key[0] != "noselodigasanadie"){
      $result->setCode(FALSE);
      $result->setStatus(403);
      $result->setMessage("Error: "."Forbidden access");
    }else{
      
  try {
    //$input = $request->getParsedBody();
    $in = $request->getParsedBody();
    $jsondata = $in["student"];
    $input = (array) json_decode($jsondata, true); 

    $dbquery = $this->db->prepare("UPDATE " . TABLE . " SET name = ?, surname = ?, address = ?, city = ?, postalCode = ?,phone = ?, email = ? WHERE id = ?");
    $dbquery->bindParam(1, $input['name']);
    $dbquery->bindParam(2, $input['surname']);
    $dbquery->bindParam(3, $input['address']);
    $dbquery->bindParam(4, $input['city']);
    $dbquery->bindParam(5, $input['postalCode']);
    $dbquery->bindParam(6, $input['phone']);
    $dbquery->bindParam(7, $input['email']);
    $dbquery->bindParam(8, $args['id']);
    $dbquery->execute();
    $number = $dbquery->rowCount();
    if ($number > 0) {
      $result->setCode(TRUE);
      $result->setStatus(OK);
    }
    else {
      $result->setCode(FALSE);
      $result->setStatus(NOT_COMPLETED);
      $result->setMessage("NOT UPDATED");
    }
  } catch (PDOException $e) {
    $result->setCode(FALSE);
    $result->setStatus(CONFLICT);
    $result->setMessage("Error: " . $e->getMessage());
  }
    return $this->response->withJson($result);
    }
});
$app->put('/incidence/[{id}]', function ($request, $response, $args) {
  $result = new Result();
   $key = $request->getHeader('apikey');
    if ($key[0] != "noselodigasanadie"){
      $result->setCode(FALSE);
      $result->setStatus(403);
      $result->setMessage("Error: "."Forbidden access");
    }else{
      
  try {
    //$input = $request->getParsedBody();
    $in = $request->getParsedBody();
    $jsondata = $in["incidence"];
    $input = (array) json_decode($jsondata, true);

    $dbquery = $this->db->prepare("UPDATE " . TABLE_INCIDENCES . " SET id_student = ?, faltas = ?, trabajo = ?, actitud = ?, observaciones = ?, date = ? WHERE id = ?");
    $dbquery->bindParam(1, $input['id_student']);
    $dbquery->bindParam(2, $input['faltas']);
    $dbquery->bindParam(3, $input['trabajo']);
    $dbquery->bindParam(4, $input['actitud']);
    $dbquery->bindParam(5, $input['observaciones']);
    $dbquery->bindParam(6, $input['date']);
    $dbquery->bindParam(7, $args['id']);
    $dbquery->execute();
    $number = $dbquery->rowCount();
    if ($number > 0) {
      $result->setCode(TRUE);
      $result->setStatus(OK);
    }
    else {
      $result->setCode(FALSE);
      $result->setStatus(NOT_COMPLETED);
      $result->setMessage("NOT UPDATED");
    }
  } catch (PDOException $e) {
    $result->setCode(FALSE);
    $result->setStatus(CONFLICT);
    $result->setMessage("Error: " . $e->getMessage());
  }
    return $this->response->withJson($result);
    }
});

$app->delete('/student/[{id}]', function ($request, $response, $args) {
  $result = new Result();
   $key = $request->getHeader('apikey');
    if ($key[0] != "noselodigasanadie"){
      $result->setCode(FALSE);
      $result->setStatus(403);
      $result->setMessage("Error: "."Forbidden access");
    }else{
      
  try {
    $dbquery = $this->db->prepare("DELETE FROM " . TABLE . " WHERE id = ?");
    $dbquery->bindParam(1, $args['id']);
    $dbquery->execute();
    $number = $dbquery->rowCount();
    if ($number > 0) {
      $result->setCode(TRUE);
      $result->setStatus(OK);
    } else {
      $result->setCode(FALSE);
      $result->setStatus(NOT_COMPLETED);
      $result->setMessage("NOT DELETED");
    }
  } catch (PDOException $e) {
    $result->setCode(FALSE);
    $result->setStatus(CONFLICT);
    $result->setMessage("Error: " . $e->getMessage());
  }
  return $this->response->withJson($result);
    }
});
$app->delete('/incidence/[{id}]', function ($request, $response, $args) {
  $result = new Result(); $key = $request->getHeader('apikey');
    if ($key[0] != "noselodigasanadie"){
      $result->setCode(FALSE);
      $result->setStatus(403);
      $result->setMessage("Error: "."Forbidden access");
    }else{
      
  try {
    $dbquery = $this->db->prepare("DELETE FROM " . TABLE_INCIDENCES . " WHERE id = ?");
    $dbquery->bindParam(1, $args['id']);
    $dbquery->execute();
    $number = $dbquery->rowCount();
    if ($number > 0) {
      $result->setCode(TRUE);
      $result->setStatus(OK);
    } else {
      $result->setCode(FALSE);
      $result->setStatus(NOT_COMPLETED);
      $result->setMessage("NOT DELETED");
    }
  } catch (PDOException $e) {
    $result->setCode(FALSE);
    $result->setStatus(CONFLICT);
    $result->setMessage("Error: " . $e->getMessage());
  }
  return $this->response->withJson($result);
    }
});

//incluye envío de emails usando alumno@portadaalta.info
$app->post("/email", function ($request, $response) {

	$input = $request->getParsedBody();
	$result = sendEmail($input['from'], $input['password'], $input['to'], $input['subject'], $input['message']);
	return $this->response->withJson($result);
});

function sendEmail($from, $password, $to, $subject, $message) {

	$result = new Result();
	$mail = new PHPMailer(true); 	// the true param means it will throw exceptions on errors, which we need to catch
	$mail->IsSMTP(); 		// telling the class to use SMTP

	try {
	    //$mail->SMTPDebug  = 2;			// enables SMTP debug information (for testing)
	    $mail->SMTPDebug  = 0;
	    $mail->SMTPAuth   = true;			// enable SMTP authentication
	    $mail->SMTPSecure = "tls";                 	// sets the prefix to the server
	    //$mail->Host       ="mail.portadaalta.info";
	    $mail->Host       = "smtp.gmail.com";      	// sets GMAIL as the SMTP server
	    //$mail->Host       = "smtp.openmailbox.org";
	    $mail->Port       = 465;                   	// set the SMTP port for the GMAIL server
	    $mail->Username   = $from;			// GMAIL username
	    $mail->Password   = $password;		// GMAIL password
	    $mail->AddAddress($to);			// Receiver email
	    $mail->SetFrom($from, 'Jesus P.');		// email sender
	    $mail->AddReplyTo($from, 'Jesus P.');		// email to reply
	    $mail->Subject = $subject;			// subject of the message
	    $mail->AltBody = 'Message in plain text';	// optional - MsgHTML will create an alternate automatically
	    $mail->MsgHTML($message);			// message in the email
	    //$mail->AddAttachment('images/phpmailer.gif');      // attachment
	    $mail->Send();
	    $result->setCode(TRUE);
	    $result->setMessage("Message Sent OK to " . $to);
	} catch (phpmailerException $e) {
	    //echo $e->errorMessage(); 			//Pretty error messages from PHPMailer
	    $result->setCode(FALSE);
    	$result->setMessage("Error: " . $e->errorMessage());
	} catch (Exception $e) {
	    //echo $e->getMessage(); 			//Boring error messages from anything else!
	    $result->setCode(FALSE);
    	$result->setMessage("Error: " . $e->getMessage());
	}
	return $result;
}
