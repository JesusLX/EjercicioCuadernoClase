<?php
  define('TABLE', "student");
  define('TABLE_INCIDENCES', "incidence");
  define('OK', 200);
  define('NOT_COMPLETED', 202);
  define('CONFLICT', 409);
  class Result {
    var $code;
    var $status;
    var $message;
    var $students;
    var $incidences;
    var $last;
    function setCode($c) {$this->code = $c;}
    function getCode() {return $this->code;}
    function setStatus($s) {$this->status = $s;}
    function getStatus() {return $this->status;}
    function setMessage($m) {$this->message = $m;}
    function getMessage() {return $this->message;}
    function setStudents($s) {$this->students = $s;}
    function getStudents() {return $this->students;}
    function setIncidences($s) {$this->incidences = $s;}
    function getIncidences() {return $this->incidences;}
    function setLast($l) {$this->last = $l;}
    function getLast() {return $this->last;}
  }
  class Student {
    var $id;
    var $name;
    var $surname;
    var $address;
    var $city;
    var $postalCode;
    var $phone;    
    var $email;
  }
  class Incidence {
    var $id;
    var $id_student;
    var $faltas;
    var $trabajo;
    var $actitud;
    var $observaciones;
    var $date;
  }
  class Email {
    var $from;
    var $password;
    var $to;
    var $subject;
    var $message;
  }
?>
